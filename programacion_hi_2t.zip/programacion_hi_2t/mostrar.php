<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=3.0">
    <title>Hito individual 2t</title>
    <link rel="icon" type="image/x-icon" href="other-green.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="estilo.css">
    <link rel="shortcut icon" href="./icono/camara.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&display=swap" rel="stylesheet">
</head>

<body>
    <nav class="barra_navegacion">
        <a href="index.php" class="menu">TEORIA</a>
        <a href="mostrar.php" class="menu">PUBLICACIONES</a><br>
        <?php 
            if(isset($_SESSION['token'])){
                echo "<a href='logout.php' class='menu'>logout</a>";
            } 
        ?>
    </nav>
<?php
include('conexion.php');
$sql= "SELECT * FROM post";
$resultado= $conn->query($sql);
//tabla
echo"<table class='table'>
<thead><td>TITULO</td><td>DESCRIPCION</td><td>FECHA DE PUBLICACION</td><td>IMAGEN</td></thead>";
while ($row=$resultado->fetch()) {
    echo("<tr class='table-success'>");
    echo("<td>".$row['TITULO']."</td>");
    echo("<td>".$row['DESCRIPCION']."</td>");
    echo("<td>".$row['FECHA_PUBLICACION']."</td>");
    echo("<td>".$row['IMAGEN']."</td>");
    echo("<td></td>");
    echo("</tr>");
} // cierra bucle

?>
<div class="contenedor_eliminar">
    <button type="button" class="btn btn-danger">Eliminar Registros</button>
</div>
</body>
</html>