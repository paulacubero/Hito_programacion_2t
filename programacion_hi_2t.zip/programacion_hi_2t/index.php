<?php
session_start();?>

<?php
// cookie
$ip=$_SERVER['REMOTE_ADDR']; //optiene la ip del equipo
$fecha=date('Y-m-d H:i:s'); //optiene la fecha actual
// cookie con ip y fecha
setcookie('ip',$ip);
setcookie('fecha_acceso',$fecha);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=3.0">
    <title>Hito individual 2t</title>
    <link rel="icon" type="image/x-icon" href="other-green.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"><!-- estilos de bootstrap -->
    <link rel="stylesheet" href="estilo.css">
    <link rel="shortcut icon" href="./icono/camara.png">
    <link rel="preconnect" href="https://fonts.googleapis.com"><!-- estilos de texto -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><!-- estilos de texto -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&display=swap" rel="stylesheet"><!-- estilos de texto -->
</head>

<body>
    <div class="todo">
        <nav class="barra_navegacion"> <!-- menu se navegación -->
            <a href="index.php" class="menu">TEORIA</a>
            <a href="mostrar.php" class="menu">PUBLICACIONES</a><br>
            <?php 
                if(isset($_SESSION['token'])){ //si el token coincide aparece en el menu la opción de subir un post
                    echo "<a href='form_post.php' class='menu'>SUBIR POST</a><br>";
                } else {
                    echo "<a href='form_register.php' class='menu'>REGISTRARSE</a><br>";
                    //si el token no coincide, aparece en el menu la opción de registrarse
                }
            ?>
            <?php 
                if(isset($_SESSION['token'])){ //si el token coincide aparece en el menu la opción de cerrar sesión
                    echo "<a href='logout.php' class='menu'>LOGOUT</a>";
                } 
            ?>
        </nav>

        <div class="flex-central">
            <div class="flex2 json">
                <div class="titulo">
                    <div>
                        Tipos de lenguajes de programación
                    </div>
                    
                </div>
            </div>


            <div class="teoria">
                <div>
                    <div style="font-size: 18px;">
                        <p>
                        <h3>Programación Orientada a Objetos (POO)</h3>
                        <p>
                            Es un paradigma de programación que se basa en el concepto de clases y objetos. Este tipo de
                            programación se utiliza para estructurar un programa de software en piezas simples y
                            reutilizables de planos de código (clases) para crear instancias individuales de objetos.
                        </p>
                        <p>
                            Lo que buscamos es dejar de centrarnos en la lógica pura de los programas, para empezar
                            a pensar en objetos, lo que constituye la base de este paradigma. Esto nos ayuda
                            muchísimo en sistemas grandes, ya que en vez de pensar en funciones, pensamos en las
                            relaciones o interacciones de los diferentes componentes del sistema.

                        </p>
                        <p>
                            La Programación Orientada a objetos permite que el código sea reutilizable, organizado y
                            fácil de mantener.
                        </p>
                        <h3>Programación Orientada a Eventos (POE)</h3>
                        <p>
                            La programación orientada a eventos es un paradigma de programación en el que tanto la
                            estructura como la ejecución de los programas van determinados por los sucesos que ocurran
                            en el sistema, definidos por el usuario o que ellos mismos provoquen.
                        </p>
                        <p>
                            Se caracteriza por el desarrollo de aplicaciones en entornos gráficos que permiten crear
                            formularios con botones de comandos, cuadros de texto y muchos otros tipos de controles,
                            además de incluir las funciones propias de un lenguaje de programación de alto nivel para
                            codificar todos los eventos e incluso, permitir enlazar a bases de datos.
                        </p>
                        <h3>Lenguajes procedimentales</h3>
                        <p>
                            Son lenguajes imperativos, que se basan en una estructura secuencial y jerarquica.
                            Están diseñados para dar instrucciones precisas a los sistemas sobre cómo deben comportarse
                            ante ciertos estímulos o valores de entrada. Con este lenguaje se pueden construir
                            herramientas digitales que procesen valores de entrada para aplicar ciertas reglas y arrojar
                            valores de salida; siempre y cuando cumplan con los requisitos del sistema.
                        </p>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <footer>
        <div >© 2023 Hito individual, Paula Cubero</div>
    </footer>
    </div>
</body>

</html>