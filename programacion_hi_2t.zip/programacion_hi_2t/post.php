<?php
    require_once('conexion.php');
    if (isset($_POST['enviar'])){ 
        $titulo=$_POST['titulo'];
        $descripcion=$_POST['descripcion'];
        $fecha=$_POST['fecha'];
        $imagen=$_POST['imagen'];
        
        $insert= "INSERT INTO post (TITULO,DESCRIPCION,FECHA_PUBLICACION,IMAGEN,ID_USUARIO) values ('$titulo','$descripcion','$fecha','$imagen',null)";
        $result= $conn->query($insert);

        header('location:mostrar.php');
    }
?>