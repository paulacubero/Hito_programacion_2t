<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hito individual 2t</title>
    <link rel="stylesheet" type="text/css" href="./diseño_registro.css">
    <link rel="stylesheet" href="estilo.css">
    <link rel="shortcut icon" href="./icono/camara.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  <nav class="botones_inicio">
  <button type="submit" class="btn btn-primary" name="enviar"><a class="texto_botones" href="./form_login.php">Sign in</a></button><!-- logearse --> 
    <button type="submit" class="btn btn-primary texto_botones" name="enviar"><a class="texto_botones" href="./form_register.php">Sign up</a></button><!-- registrarse -->
  </nav>
  <!-- el usuario se logea -->
  <div class="contorno_form">
    <h2 class="form_titulo">Login</h2>
    <form class="form_login" action='login.php' method='post'>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Email</label>
          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
          <div id="emailHelp" class="form-text" ></div>
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Password</label>
          <input type="password" class="form-control" id="exampleInputPassword1" name="pass">
        </div>
        <button type="submit" class="btn btn-primary" name="enviar">Enviar</button>
    </form>
  </div>
  <?php
  require_once('login.php');
  ?>
</body>
</html>