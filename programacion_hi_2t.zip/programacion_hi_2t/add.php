<?php
session_start();
if(isset($_SESSION['token'])){
echo $_SESSION['token'];
//echo session_id();

    if($_SESSION['token']==session_id()){

    require_once('./conexion.php');

    $insertar="INSERT INTO `hito` (`id`, `nombre`, `unidades`, `precio`, `fechaCaducidad`) 
    VALUES (NULL, 'sombrero', '14', '9.95', '2023-02-01')";
    $registro= $conn->exec($insertar);


    if ($registro){
        echo "Se han activado $registro registros.";
    }
    }//cierre if

    else{
        echo("Hay sesión pero no te reconozco");
    }
}// cierre isset
else{
    echo("No hay sesion");
}
