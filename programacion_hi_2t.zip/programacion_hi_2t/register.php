<?php
    require_once('conexion.php'); // se conenta a la bdd 
    if (isset($_POST['enviar'])){ // si se pulsado enviar hace lo siguiente
        $email=$_POST['email']; // almacena el email
        $pass=$_POST['pass']; // almacena la contraseña
        
        $insert= "INSERT INTO registro (email,contraseña) values ('$email','$pass')"; 
        // mediante un insert se guarda la información de estos valores en mi bdd
        $result= $conn->query($insert); // se crea una query
        
        header('location:form_login.php'); //rederije a la pagina del formulario login
    }
?>

