<?php
    require_once('conexion.php');
    if (isset($_POST['enviar'])){
        $email=$_POST['email'];
        $pass=$_POST['pass'];
        
        $select= "select * from registro where email='".$email."'";
        $result= $conn->query($select);
        $row=$result->fetch();/*fetch permite meter la tabla en un array y leerlo*/
        if ($email==$row['email'] and $pass==$row['contraseña']){
            header('location:index.php');
            session_start();
            $_SESSION['token']='user';
        }
        else{
            echo('Login fallido');
        }
    }
?>

